
const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const path = require('path');

let users = [];

app.use(express.static(path.join(__dirname, 'public')));

io.on('connection', (socket) => {
  let username = "";

  socket.on("join", (name) => {
    username = name;
    users.push(username);
    io.emit("userList", users);
  });

  socket.on("privateMessage", ({ from, to, message }) => {
    socket.broadcast.emit("privateMessage", { from, message });
  });

  socket.on("disconnect", () => {
    users = users.filter(u => u !== username);
    io.emit("userList", users);
  });
});

http.listen(3000, () => {
  console.log("Mestein chat is running on port 3000");
});
