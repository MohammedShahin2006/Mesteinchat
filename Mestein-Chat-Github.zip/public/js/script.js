
const socket = io();
let currentUser = "";
let currentChat = "";

function joinChat() {
  const username = document.getElementById("username").value.trim();
  if (username) {
    currentUser = username;
    document.getElementById("login-screen").classList.add("hidden");
    document.getElementById("chat-screen").classList.remove("hidden");
    document.getElementById("welcome-user").textContent = "مرحباً " + username;
    socket.emit("join", username);
  }
}

socket.on("userList", (users) => {
  const list = document.getElementById("user-list");
  list.innerHTML = "";
  users.filter(u => u !== currentUser).forEach(user => {
    const li = document.createElement("li");
    li.textContent = user;
    li.onclick = () => startChat(user);
    list.appendChild(li);
  });
});

function searchUsers() {
  const search = document.getElementById("search").value.toLowerCase();
  Array.from(document.querySelectorAll("#user-list li")).forEach(li => {
    li.style.display = li.textContent.toLowerCase().includes(search) ? "block" : "none";
  });
}

function startChat(user) {
  currentChat = user;
  document.getElementById("chat-with").textContent = "الدردشة مع " + user;
  document.getElementById("chat-box").classList.remove("hidden");
  document.getElementById("messages").innerHTML = "";
}

function sendMessage(event) {
  if (event.key === "Enter") {
    const msg = document.getElementById("message-input").value.trim();
    if (msg && currentChat) {
      socket.emit("privateMessage", {
        from: currentUser,
        to: currentChat,
        message: msg
      });
      appendMessage(currentUser + ": " + msg);
      document.getElementById("message-input").value = "";
    }
  }
}

socket.on("privateMessage", ({ from, message }) => {
  if (from === currentChat) {
    appendMessage(from + ": " + message);
  }
});

function appendMessage(msg) {
  const messages = document.getElementById("messages");
  const div = document.createElement("div");
  div.textContent = msg;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}
